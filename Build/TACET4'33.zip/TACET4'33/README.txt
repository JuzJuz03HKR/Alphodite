TACET 4'33 (Beta1, 3 Nov 2026)

Run Tacetno433.exe in this folder. Windows 64-bit. No .NET install needed.
Mouse = the baton. Credits : the CREDITS page in the game (C on the title).
